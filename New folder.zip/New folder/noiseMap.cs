using UnityEngine;
using Unity.Mathematics;

public struct NoiseMapResult
{
    public float[,] noiseMap;
    public float minHeight;
    public float maxHeight;
}

public static class NoiseMapGenerator
{
    public enum NormalizeMode { Local, Global }

    public static NoiseMapResult GenerateNoiseMap(
        int seed, int width, int height,
        float scale,
        int octaves,
        float persistence,
        float lacunarity,
        Vector2 offset,
        float weight,
        NormalizeMode normalizeMode
    )
    {
        float[,] noiseMap = new float[width, height];

        if (scale <= 0f)
            scale = 0.0001f;

        System.Random prng = new System.Random(seed);
        Vector2[] octaveOffsets = new Vector2[octaves];

        for (int i = 0; i < octaves; i++)
        {
            float offsetX = prng.Next(-100000, 100000) + offset.x;
            float offsetY = prng.Next(-100000, 100000) + offset.y;
            octaveOffsets[i] = new Vector2(offsetX, offsetY);
        }

        float maxNoiseHeight = float.MinValue;
        float minNoiseHeight = float.MaxValue;

        float halfWidth = width / 2f;
        float halfHeight = height / 2f;

        for (int y = 0; y < height; y++)
        {
            for (int x = 0; x < width; x++)
            {
                float2 pos = new float2(x, y);

                float ridgeVal = OctavedRidgeNoise(pos, seed, scale, octaves, lacunarity, persistence, octaveOffsets, width, height, weight);
                float simplexVal = OctavedSimplexNoise(pos, seed, scale, octaves, lacunarity, persistence, octaveOffsets, width, height);
                float noiseHeight = (ridgeVal + simplexVal) / 2f;
                if (float.IsNaN(noiseHeight) || float.IsInfinity(noiseHeight) || Mathf.Abs(noiseHeight) > 1000f)
                {
                    Debug.LogWarning($"Bad noise at ({x},{y}) = {noiseHeight}");
                    noiseHeight = 0;
                }

                if (!float.IsNaN(noiseHeight) && !float.IsInfinity(noiseHeight) && noiseHeight < 1000f)
                {
                    if (noiseHeight > maxNoiseHeight) maxNoiseHeight = noiseHeight;
                    if (noiseHeight < minNoiseHeight) minNoiseHeight = noiseHeight;
                }

                if (float.IsNaN(noiseHeight) || float.IsInfinity(noiseHeight) || noiseHeight > 1000f)
                {
                    Debug.LogWarning($"Bad noise at ({x}, {y}): {noiseHeight} from pos {pos}");
                    noiseHeight = 0f;
                }


                noiseMap[x, y] = noiseHeight;
            }
        }

        // Normalize the noise
        for (int y = 0; y < height; y++)
        {
            for (int x = 0; x < width; x++)
            {
                if (normalizeMode == NormalizeMode.Local)
                {
                    noiseMap[x, y] = Mathf.InverseLerp(minNoiseHeight, maxNoiseHeight, noiseMap[x, y]);
                }
                if (normalizeMode == NormalizeMode.Global)
                {
                    float gMin = EndlessTerrain.globalMinHeight;
                    float gMax = EndlessTerrain.globalMaxHeight;

                    if (gMax == gMin)
                        Debug.LogError("Global normalization failed: min == max");

                    noiseMap[x, y] = Mathf.InverseLerp(gMin, gMax, noiseMap[x, y]);
                }

            }
        }

        return new NoiseMapResult
        {
            noiseMap = noiseMap,
            minHeight = minNoiseHeight,
            maxHeight = maxNoiseHeight
        };

    }

    private static float OctavedRidgeNoise(
        float2 pos, int seed, float scale, int octaves, float lacunarity, float persistence,
        Vector2[] octaveOffsets, int width, int height, float weight)
    {
        float noiseVal = 0f;
        float amplitude = 1f;
        float frequency = 1f;
        float currentWeight = 1f;

        float halfWidth = width / 2f;
        float halfHeight = height / 2f;

        for (int i = 0; i < octaves; i++)
        {
            float sampleX = (pos.x - halfWidth) / scale * frequency + octaveOffsets[i].x * frequency;
            float sampleY = (pos.y - halfHeight) / scale * frequency - octaveOffsets[i].y * frequency;

            float n = OpenSimplex2S.Noise2_ImproveX(seed, sampleX, sampleY);
            float v = 1f - Mathf.Abs(n);
            v *= v;
            v *= currentWeight;

            currentWeight = Mathf.Clamp01(v * weight);

            noiseVal += v * amplitude;

            frequency *= lacunarity;
            amplitude *= persistence;
        }

        return noiseVal;
    }

    private static float OctavedSimplexNoise(
        float2 pos, int seed, float scale, int octaves, float lacunarity, float persistence,
        Vector2[] octaveOffsets, int width, int height)
    {
        float noiseVal = 0f;
        float amplitude = 1f;
        float frequency = 1f;

        float halfWidth = width / 2f;
        float halfHeight = height / 2f;

        for (int i = 0; i < octaves; i++)
        {
            float sampleX = (pos.x - halfWidth) / scale * frequency + octaveOffsets[i].x * frequency;
            float sampleY = (pos.y - halfHeight) / scale * frequency - octaveOffsets[i].y * frequency;

            float n = OpenSimplex2S.Noise2_ImproveX(seed, sampleX, sampleY);
            float v = (n + 1f) / 2f;

            noiseVal += v * amplitude;

            frequency *= lacunarity;
            amplitude *= persistence;
        }

        return noiseVal;
    }
}
