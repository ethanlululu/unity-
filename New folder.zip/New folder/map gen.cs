﻿// --- MapGenerator.cs ---

using UnityEngine;
using System;
using System.Collections.Generic;

public class MapGenerator : MonoBehaviour
{
    public enum DrawMode { NoiseMap, ColourMap, Mesh };
    public DrawMode drawMode;

    public NoiseMapGenerator.NormalizeMode normalizeMode;

    public const int mapChunkSize = 241;
    [Range(0, 6)]
    public int editorPreviewLOD;
    public float noiseScale;

    public int octaves;
    [Range(0, 1)]
    public float persistance;
    public float lacunarity;

    public int seed;
    public Vector2 offset;

    public float meshHeightMultiplier;
    public AnimationCurve meshHeightCurve;

    public float wight;

    public bool autoUpdate;

    public TerrainType[] regions;

    Queue<MapThreadInfo<MapData>> mapDataThreadInfoQueue = new Queue<MapThreadInfo<MapData>>();
    Queue<MapThreadInfo<MeshData>> meshDataThreadInfoQueue = new Queue<MapThreadInfo<MeshData>>();

    public void DrawMapInEditor()
    {
        MapData mapData = GenerateMapData(Vector2.zero, true);

        MapDisplay display = FindObjectOfType<MapDisplay>();
        if (drawMode == DrawMode.NoiseMap)
        {
            display.DrawTexture(TextureGenerator.TextureFromHeightMap(mapData.heightMap));
        }
        else if (drawMode == DrawMode.ColourMap)
        {
            display.DrawTexture(TextureGenerator.TextureFromColourMap(mapData.colourMap, mapChunkSize, mapChunkSize));
        }
        else if (drawMode == DrawMode.Mesh)
        {
            display.DrawMesh(MeshGenerator.GenerateTerrainMesh(mapData.heightMap, meshHeightMultiplier, meshHeightCurve, editorPreviewLOD), TextureGenerator.TextureFromColourMap(mapData.colourMap, mapChunkSize, mapChunkSize));
        }
    }

    public void RequestMapData(Vector2 centre, Action<MapData> callback)
    {
        System.Threading.ThreadStart threadStart = delegate
        {
            MapDataThread(centre, callback);
        };

        new System.Threading.Thread(threadStart).Start();
    }

    void MapDataThread(Vector2 centre, Action<MapData> callback)
    {
        MapData mapData = GenerateMapData(centre);
        lock (mapDataThreadInfoQueue)
        {
            mapDataThreadInfoQueue.Enqueue(new MapThreadInfo<MapData>(callback, mapData));
        }
    }

    public void RequestMeshData(MapData mapData, int lod, Action<MeshData> callback)
    {
        System.Threading.ThreadStart threadStart = delegate
        {
            MeshDataThread(mapData, lod, callback);
        };

        new System.Threading.Thread(threadStart).Start();
    }

    void MeshDataThread(MapData mapData, int lod, Action<MeshData> callback)
    {
        MeshData meshData = MeshGenerator.GenerateTerrainMesh(mapData.heightMap, meshHeightMultiplier, meshHeightCurve, lod);

        // Clamp meshData heights here if you want (optional)

        lock (meshDataThreadInfoQueue)
        {
            meshDataThreadInfoQueue.Enqueue(new MapThreadInfo<MeshData>(callback, meshData));
        }
    }

    void Update()
    {
        if (mapDataThreadInfoQueue.Count > 0)
        {
            for (int i = 0; i < mapDataThreadInfoQueue.Count; i++)
            {
                MapThreadInfo<MapData> threadInfo = mapDataThreadInfoQueue.Dequeue();
                threadInfo.callback(threadInfo.parameter);
            }
        }

        if (meshDataThreadInfoQueue.Count > 0)
        {
            for (int i = 0; i < meshDataThreadInfoQueue.Count; i++)
            {
                MapThreadInfo<MeshData> threadInfo = meshDataThreadInfoQueue.Dequeue();
                threadInfo.callback(threadInfo.parameter);
            }
        }
    }

    MapData GenerateMapData(Vector2 centre, bool debugEdges = false)
    {
        var result = NoiseMapGenerator.GenerateNoiseMap(
            seed, mapChunkSize, mapChunkSize,
            noiseScale, octaves, persistance, lacunarity,
            centre + offset, wight, normalizeMode
        );

        // Debug log global min/max once per chunk
        Debug.Log($"GlobalMin: {EndlessTerrain.globalMinHeight:F4}, GlobalMax: {EndlessTerrain.globalMaxHeight:F4}");

        float[,] noiseMap = result.noiseMap;

        // Generate colour map
        Color[] colourMap = new Color[mapChunkSize * mapChunkSize];
        for (int y = 0; y < mapChunkSize; y++)
        {
            for (int x = 0; x < mapChunkSize; x++)
            {
                float currentHeight = noiseMap[x, y];
                for (int i = 0; i < regions.Length; i++)
                {
                    if (currentHeight <= regions[i].height)
                    {
                        colourMap[y * mapChunkSize + x] = regions[i].colour;
                        break;
                    }
                }
            }
        }

        return new MapData(noiseMap, colourMap, result.minHeight, result.maxHeight);
    }

    public void PrecomputeGlobalMinMax()
    {
        float min = float.PositiveInfinity;
        float max = float.NegativeInfinity;

        int range = 1; // You can increase to get better global min/max

        for (int y = -range; y <= range; y++)
        {
            for (int x = -range; x <= range; x++)
            {
                Vector2 center = new Vector2(x, y) * (mapChunkSize - 1);
                var result = NoiseMapGenerator.GenerateNoiseMap(
                    seed, mapChunkSize, mapChunkSize, noiseScale,
                    octaves, persistance, lacunarity,
                    center + offset, wight, NoiseMapGenerator.NormalizeMode.Local // Always local here
                );

                if (!float.IsNaN(result.minHeight) && !float.IsInfinity(result.minHeight))
                    min = Mathf.Min(min, result.minHeight);
                if (!float.IsNaN(result.maxHeight) && !float.IsInfinity(result.maxHeight))
                    max = Mathf.Max(max, result.maxHeight);
            }
        }

        EndlessTerrain.globalMinHeight = min;
        EndlessTerrain.globalMaxHeight = max;

        Debug.Log($"[Precompute] Global Min = {min}, Max = {max}");
    }

    struct MapThreadInfo<T>
    {
        public readonly Action<T> callback;
        public readonly T parameter;

        public MapThreadInfo(Action<T> callback, T parameter)
        {
            this.callback = callback;
            this.parameter = parameter;
        }
    }
}

[System.Serializable]
public struct TerrainType
{
    public string name;
    public float height;
    public Color colour;
}

public struct MapData
{
    public readonly float[,] heightMap;
    public readonly Color[] colourMap;
    public readonly float minHeight;
    public readonly float maxHeight;

    public MapData(float[,] heightMap, Color[] colourMap, float minHeight, float maxHeight)
    {
        this.heightMap = heightMap;
        this.colourMap = colourMap;
        this.minHeight = minHeight;
        this.maxHeight = maxHeight;
    }
}
